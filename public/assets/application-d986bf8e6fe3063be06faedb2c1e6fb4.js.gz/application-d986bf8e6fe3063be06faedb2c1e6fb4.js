// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function toggle_holder(){elem=document.getElementById("item_status"),showProp=elem.value=="Requisitado"?"inline":"none",document.getElementById("holder_toggle").style.display=showProp}